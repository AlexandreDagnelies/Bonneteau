/*
 * iDol Module Parameters
 * @author Dolmen Technologies
 *
 * Contains parameters passed to the module through the context object
 */

var context = 
{ 
	
};